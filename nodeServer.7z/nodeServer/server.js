var express = require('express');
const cors = require('cors');
var app = express();

app.use(express.static('html-client'));
var corsOptions = {
    origin: 'http://localhost:8081',
    optionsSuccessStatus: 200, // For legacy browser support
    methods: "GET, PUT"
}
app.use(cors(corsOptions));
app.get('/', function (req, res) {
	//req.setHeader('Access-Control-Allow-Origin', '*');
	res.setHeader('Access-Control-Allow-Origin', '*');
   res.sendFile( __dirname + "/html-client/" + "imageProcessor.html" );
})

var server = app.listen(8081, function () {
   var host = server.address().address
   var port = server.address().port
   
   console.log("Example app listening at http://%s:%s", host, port)
})